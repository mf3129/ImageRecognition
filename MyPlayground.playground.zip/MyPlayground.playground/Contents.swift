import CreateMLUI

let builder = MLImageClassifierBuilder()
builder.showInLiveView()
